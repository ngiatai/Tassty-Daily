// data for search

const SEARCH_PRODUCT_DATA = [
    {
        id: 1,
        name: 'Evian Still Water in 500 ml x12',
        description:
            'It’s a uniquely sourced spring water that’s always refreshing and naturally hydrating.',
        image: 'Evian-Still-Water.jpg',
        type: 'Water',
        price: 20,
    },
    {
        id: 2,
        name: 'Spring Onions 1 bunch',
        description:
            'Go for spring onions with firm, unblemished bulbs and bright green, perky leaves.',
        image: 'img26.jpg',
        type: 'Leafy Green',
        price: 10,
    },
    {
        id: 3,
        name: 'Red Radish 1 pack',
        description:
            'The color of a radish is a strong indicator of its taste. Pick the ones that are a rich, full red.',
        image: 'img-09.jpg',
        type: 'Root',
        price: 20,
    },
    {
        id: 4,
        name: 'Avocados 2 Units',
        description: 'Avocados are a rich source of vitamins C, E, K, and B-6.',
        image: 'img-01.jpg',
        type: 'Tropical & Exotic',
        price: 60,
    },
    {
        id: 5,
        name: 'Oyster Mushroom 500 gr',
        description:
            'Oyster Mushrooms are a healthy choice since they are very nutritious and low in calories.',
        image: 'img21.jpg',
        type: 'Mushrooms',
        price: 12,
    },
    {
        id: 6,
        name: 'Carrots 1 kg',
        description:
            'Carrots can be stored in the refrigerator for up to a month if stored properly.',
        image: 'img29.jpg',
        type: 'Root',
        price: 10,
    },
    {
        id: 7,
        name: 'Basil',
        description:
            'To keep basil fresh, trim thex stems and place them in a glass or jar of water.',
        image: 'img19.jpg',
        type: 'Leafy Green',
        price: 8,
    },
    {
        id: 8,
        name: 'Menissez Mini Pains Bake At Home',
        description:
            'The 300g part-baked white rolls are packed by 6 and weigh approximately 50g each.',
        image: 'img30.jpg',
        type: 'Bread',
        price: 15,
    },
    {
        id: 9,
        name: 'Delicious Grapes',
        description:
            'xGrapes are fat free and very low in sodium. Grapes are a very good source of vitamin K.',
        image: 'img-04.jpg',
        type: 'Apple & Stone Fruits',
        price: 14,
    },
    {
        id: 10,
        name: 'Halal Chuck Steak 500 gr',
        description:
            'Wrap the meat in freezer paper, freezer bags or aluminum foil.',
        image: 'img-06.jpg',
        type: 'Red Meat & Steaks',
        price: 350,
    },
    {
        id: 11,
        name: 'Cow Cheese | Comte Jura (10+ mons) from France | 500gr',
        description:
            'Comté is a traditional, hard cheese with similar characteristics to the Swiss gruyere.',
        image: 'img31.jpg',
        type: 'Cheese',
        price: 17,
    },
    {
        id: 12,
        name: 'Blueberries 125 gr',
        description:
            'Carefully hand-picked, these blueberries are crisp and fresh.',
        image: 'img32.jpg',
        type: 'Berries',
        price: 40,
    },
    {
        id: 13,
        name: 'Free-range Eggs 6 pack',
        description: 'Fresh free range eggs contain high amounts of protein.',
        image: 'img34.jpg',
        type: 'Chicken Eggs',
        price: 20,
    },
    {
        id: 14,
        name: 'Green Apples',
        description:
            'Green apples delivered fresh! Crisp,fresh and hand-picked! Essential for your kitchen.',
        image: 'img-11.jpg',
        type: 'Apple & Stone Fruits',
        price: 10,
    },
    {
        id: 15,
        name: 'King Prawns Peeled in Brine 900gr',
        description:
            'Great for a healthy salad and sandwiches, mix with our crayfish tails to make an even better sandwich.',
        image: 'img-13.jpg',
        type: 'Other Seafood',
        price: 30,
    },
    {
        id: 16,
        name: 'Fresh Live Lobster ~1.75kg',
        description:
            '100 grams of cooked lobster is approximately 90 calories with 19 grams of protein.',
        image: 'img16.jpg',
        type: 'Lobsters',
        price: 120,
    },
    {
        id: 17,
        name: 'Oak Smoked Salmon 400 gr',
        description:
            'Our delicious oak smoked Salmon is an excellent source of protein.',
        image: 'imh17.jpg',
        type: 'Fish',
        price: 40,
    },
    {
        id: 18,
        name: 'BenOrganic 100% Apple Juice 250ml',
        description:
            'BenOrganic 100% Apple Juice is a premium quality beverage made from the freshest and most delicious organic apples.',
        image: 'img18.jpg',
        type: 'Juice',
        price: 15,
    },
    {
        id: 19,
        name: 'Kiwi',
        description:
            'Kiwi is a small, oval-shaped fruit with a brown fuzzy exterior and vibrant green interior.',
        image: 'img24.jpg',
        type: 'Tropical & Exotic',
        price: 10,
    },
    {
        id: 20,
        name: 'Ciabatta Bake At Home 4 Pack',
        description:
            'Ciabatta is a white bread that stems from a baker in Rovigo, Veneto, Italy.',
        image: 'img25.jpg',
        type: 'Bread',
        price: 8,
    },
];

/**
 * searchProducts search product by name, description, type
 * 
 * @param { string } q
 * @returns { Promise<{
    id: number;
    name: string;
    description: string;
    image: string;
    type: string;
    price: number;
 }[]]>} products 
 */
function searchProducts(q) {
    return new Promise((resolve) => {
        setTimeout(() => {
            const query = q.toLowerCase().trim();

            if (query.length == 0) {
                resolve([]);
                return;
            }

            resolve(
                SEARCH_PRODUCT_DATA.filter((item) => {
                    let isMatch = false;

                    isMatch = item.type.toLowerCase().includes(query);
                    if (isMatch) return true;

                    isMatch = item.name.toLowerCase().includes(query);
                    if (isMatch) return true;

                    isMatch = item.description.toLowerCase().includes(query);
                    if (isMatch) return true;

                    return false;
                })
            );
        }, 1000);
    });
}
