/**
 * initSortButton
 * @param {HTMLElement} sortButton
 */
function initSortButton(sortButton) {
    function handleClose() {
        sortButton.setAttribute('data-state', 'close');
    }

    sortButton.addEventListener('click', () => {
        let isOpen = sortButton.getAttribute('data-state') === 'open';

        if (isOpen) return;

        setTimeout(() => sortButton.setAttribute('data-state', 'open'));
    });

    window.addEventListener('click', handleClose);

    const current = sortButton.querySelector('span');
    const list = sortButton.querySelector('ul');

    list.addEventListener('click', (e) => {
        const children = list.children;

        for (const child of children) {
            child.removeAttribute('data-state');
        }
        e.target.setAttribute('data-state', 'selected');
        current.textContent = e.target.textContent;
    });
}

/**
 * initUnitsButton
 * @param {HTMLElement} unitsButton
 */
function initUnitsButton(unitsButton) {
    const unitsText = unitsButton.querySelector(
        '.units-selector__dorp-down-group__label'
    );
    const input = unitsButton.querySelector('input');
    const clearButton = unitsButton.querySelector('button');
    const notFoundLabel = unitsButton.querySelector(
        '.units-selector__dorp-down-group__not-found'
    );

    let clickInput = false;
    input.addEventListener('mousedown', () => {
        clickInput = true;
    });

    input.addEventListener('click', (e) => {
        clickInput = false;
        e.stopPropagation();

        return false;
    });

    function handleClose() {
        clickInput = false;
        unitsButton.setAttribute('data-state', 'close');
    }

    unitsButton.addEventListener('click', () => {
        let isOpen = unitsButton.getAttribute('data-state') === 'open';

        if (isOpen) {
            return;
        }

        setTimeout(() => {
            const { y } = unitsButton.getBoundingClientRect();
            const isOpenOnTop = y / window.innerHeight > 0.5;

            if (isOpenOnTop) {
                unitsButton.setAttribute('data-dir', 'top');
            } else {
                unitsButton.setAttribute('data-dir', 'bottom');
            }

            unitsButton.setAttribute('data-state', 'open');
        });
    });

    window.addEventListener('click', () => {
        if (clickInput) {
            clickInput = false;
            return;
        }
        handleClose();
    });

    const current = unitsButton.querySelector('span');
    const list = unitsButton.querySelector('ul');

    list.addEventListener('mouseover', (e) => {
        if (e.target.tagName !== 'LI') return;

        const children = list.children;

        for (const child of children) {
            child.removeAttribute('data-active');
        }

        e.target.setAttribute('data-active', 'active');
    });

    list.addEventListener('click', (e) => {
        const children = list.children;

        for (const child of children) {
            child.removeAttribute('data-state');
        }
        e.target.setAttribute('data-state', 'selected');

        unitsButton.setAttribute('value', e.target.textContent);
        current.textContent = e.target.textContent;
    });

    input.addEventListener('keyup', (e) => {
        const value = e.target.value.toLocaleLowerCase().trim();
        const children = list.children;

        let isFound = false;
        for (const child of children) {
            if (child.tagName !== 'LI') continue;

            if (child.textContent.toLocaleLowerCase().includes(value)) {
                isFound = true;
                child.style.display = 'block';
            } else {
                child.style.display = 'none';
            }
        }

        if (!isFound) {
            notFoundLabel.style.display = 'block';
        } else {
            notFoundLabel.style.display = 'none';
        }
    });

    clearButton.addEventListener('click', (e) => {
        const children = list.children;

        for (const child of children) {
            child.removeAttribute('data-state');
        }
        unitsButton.setAttribute('value', '');
        unitsText.textContent = 'Any Units';

        e.stopPropagation();
    });
}

/**
 * intiPriceFilter initializes the events for price filter components
 *
 * @param {HTMLElement} container
 * @param {number} max - must divisible by 10
 */
function intiPriceFilter(container, max) {
    const slider = container.querySelector('.price-filter__slider');

    const leftHandler = slider.querySelector(
        '.price-filter__slider__handler--left'
    );
    const rightHandler = slider.querySelector(
        '.price-filter__slider__handler--right'
    );
    const sliderValue = document.querySelector('.price-filter__price-label');

    let currentMinPrice = 0;
    let currentMaxPrice = max;
    const MAX_PRICE = max;

    let isMouseDownOnLeftHandler = false;
    let isMouseDownOnRightHandler = false;

    function handleSetMaxPrice(price) {
        if (price < currentMinPrice) return;

        currentMaxPrice = price;
        slider.style.paddingRight = `${Math.floor(
            100 - (price / MAX_PRICE) * 100
        )}%`;

        leftHandler.style.zIndex = 1;
        rightHandler.style.zIndex = 2;

        sliderValue.textContent = `Price: $${currentMinPrice} - $${currentMaxPrice}`;
    }

    function handleSetMinPrice(price) {
        if (price > currentMaxPrice) return;

        currentMinPrice = price;
        slider.style.paddingLeft = `${Math.floor((price / MAX_PRICE) * 100)}%`;

        leftHandler.style.zIndex = 2;
        rightHandler.style.zIndex = 1;

        sliderValue.textContent = `Price: $${currentMinPrice} - $${currentMaxPrice}`;
    }

    slider.addEventListener('click', (event) => {
        const { x } = slider.getBoundingClientRect();
        const sliderWidth = slider.offsetWidth;
        const newPosition = event.clientX - x;

        if (newPosition < 0 || newPosition > sliderWidth) return;

        const percentage = newPosition / sliderWidth;
        const price = Math.round((0 + percentage * (MAX_PRICE - 0)) / 10) * 10;

        if (
            Math.abs(currentMinPrice - price) >
            Math.abs(currentMaxPrice - price)
        ) {
            handleSetMaxPrice(price);
            return;
        } else {
            handleSetMinPrice(price);
            return;
        }
    });

    function handleMove(event) {
        removeUserSelected();
        const { x } = slider.getBoundingClientRect();

        const sliderWidth = slider.offsetWidth;
        const newPosition = event.clientX - x;

        if (newPosition < 0 || newPosition > sliderWidth) return;

        const percentage = newPosition / sliderWidth;
        const price = Math.round((0 + percentage * (MAX_PRICE - 0)) / 10) * 10;

        if (isMouseDownOnRightHandler) {
            handleSetMaxPrice(price);
            return;
        } else if (isMouseDownOnLeftHandler) {
            handleSetMinPrice(price);
            return;
        }
    }

    leftHandler.addEventListener('mousedown', () => {
        isMouseDownOnLeftHandler = true;
        slider.style.transition = 'none';

        document.addEventListener('mousemove', handleMove);
    });

    rightHandler.addEventListener('mousedown', () => {
        isMouseDownOnRightHandler = true;
        slider.style.transition = 'none';

        document.addEventListener('mousemove', handleMove);
    });
    window.addEventListener('mouseup', () => {
        isMouseDownOnLeftHandler = false;
        isMouseDownOnRightHandler = false;
        slider.style.transition = '';

        document.removeEventListener('mousemove', handleMove);
    });
}

/**
 * initProductsSideBar initializes the events for products list side bar
 *
 * @param {number} offsetTop - offset top
 */
function initProductsListSideBar(offsetTop = 0) {
    const sideBarContainer = document.querySelector(
        '.products-container__side-bar'
    );
    const sideBarWrap = document.querySelector(
        '.products-container__side-bar__wrap'
    );

    let lastScroll = document.documentElement.scrollTop;
    let lastScrollDir = false; // true when scroll up

    // handle resize sideBarWrap when window resize
    window.addEventListener('resize', () => {
        sideBarWrap.style.width = `${sideBarContainer.offsetWidth}px`;
    });

    // handle scroll event
    document.addEventListener('scroll', () => {
        const containerRect = sideBarContainer.getBoundingClientRect();
        const sideBarRect = sideBarWrap.getBoundingClientRect();

        const maxPadding = containerRect.height - sideBarRect.height;

        const isScrollUp = lastScroll - document.documentElement.scrollTop > 0;
        lastScroll = document.documentElement.scrollTop;

        const windowHeight = window.innerHeight;
        const isBottom = sideBarRect.bottom < windowHeight;
        const isTop = sideBarRect.top > offsetTop - 1;

        if (!isScrollUp && isBottom) {
            const newPadding =
                windowHeight - sideBarRect.height - containerRect.y;

            if (newPadding >= maxPadding) {
                sideBarContainer.style.paddingTop = `${maxPadding}px`;
                sideBarWrap.style.position = 'relative';
            } else {
                sideBarContainer.style.paddingTop = `${newPadding}px`;
                sideBarWrap.style.width = `${sideBarContainer.offsetWidth}px`;
                sideBarWrap.style.position = 'fixed';
                sideBarWrap.style.bottom = `${0.1}px`;
                sideBarWrap.style.top = '';
            }
        } else if (isScrollUp && isTop) {
            const newPadding = offsetTop - containerRect.y;

            if (newPadding < 0) {
                sideBarContainer.style.paddingTop = `${0}px`;
                sideBarWrap.style.top = `${0}px`;
                sideBarWrap.style.position = 'relative';
            } else {
                sideBarContainer.style.paddingTop = `${newPadding}px`;
                sideBarWrap.style.width = `${sideBarContainer.offsetWidth}px`;
                sideBarWrap.style.position = 'fixed';
                sideBarWrap.style.top = `${offsetTop}px`;
                sideBarWrap.style.bottom = '';
            }
        }
        // just set when scrolling to the same direction
        else if (lastScrollDir === isScrollUp) {
            sideBarWrap.style.top = '';
            sideBarWrap.style.bottom = '';
            sideBarWrap.style.position = 'relative';
        }
        lastScrollDir = isScrollUp;
    });
}

// main
(() => {
    initHeaderShadowEvents(undefined, 56);

    const openSearchButton = document.getElementById('open-search-button');
    openSearchButton.addEventListener('click', () => {
        openSearchModal();
    });
    initSearchModal();

    initMenuContentLargeEvents();

    const sortButton = document.querySelector(
        '.products-container__content__header__sorting'
    );
    initSortButton(sortButton);

    const unitsButtonElement = document.querySelector(
        '.units-selector__dorp-down-group'
    );
    initUnitsButton(unitsButtonElement);

    const priceFilterElement = document.querySelector('.price-filter');
    intiPriceFilter(priceFilterElement, 30);
    initProductsListSideBar(90);
})();
