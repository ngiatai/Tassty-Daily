document.addEventListener('DOMContentLoaded', function() {

const languageContainer = document.querySelector('.select_language_container');
const languageContent = document.querySelector('.select_language_content');
const selectedLanguage = document.getElementById('selected_language');
languageContainer.addEventListener('click', () => {
    languageContainer.classList.toggle('active');
    languageContent.style.display = languageContent.style.display === 'block' ? 'none' : 'block';
});


document.querySelectorAll('.select_language_content ul li').forEach(item => {
    item.addEventListener('click', (e) => {
        const lang = e.target.textContent;
        selectedLanguage.textContent = lang;
        languageContent.style.display = 'none'; 
        languageContainer.classList.remove('active');
    });
});
})