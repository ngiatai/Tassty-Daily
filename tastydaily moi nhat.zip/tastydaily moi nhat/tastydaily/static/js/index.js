// helper

/**
 * debounce is a helper create a new debounce func
 * @param { (...any) => void } func
 * @param { number } delay
 * @returns (...any) => void
 */
function debounce(func, delay) {
    let timeoutID = undefined;
    return function (...a) {
        clearTimeout(timeoutID);
        timeoutID = setTimeout(() => func(...a), delay);
    };
}

//

const MAX_MENU_CONTENT_SIZE = 900;

function initCategoriesMenuButtonEvent() {
    const menuButton = document.getElementsByClassName('categories-button')[0];
    if (!menuButton) return;

    const content = document.getElementsByClassName(
        'categories-menu-content'
    )[0];
    if (!content) return;

    function handler() {
        const { right } = menuButton.getBoundingClientRect();

        const contentLeft =
            window.innerWidth - 100 - MAX_MENU_CONTENT_SIZE - right;

        content.style.left = `${contentLeft < 0 ? contentLeft : 0}px`;
    }

    window.addEventListener('resize', handler);
    menuButton.addEventListener('mouseenter', handler);
}

/**
 * getParentMenuGroup
 * @param {HTMLElement} container
 * @returns {HTMLElement | null}
 */
function getParentMenuGroup(container) {
    const parent = container.parentElement;

    if (!parent) return null;
    const isMenuGroup = parent.classList.contains('menu-group');
    if (isMenuGroup) return parent;

    return getParentMenuGroup(parent);
}

const MAX_MENU_CONTENT_LARGE_SIZE = 1160;
function initMenuContentLargeEvents() {
    const menuContentLarge = document.getElementsByClassName(
        'menu-content--large'
    );

    for (let i = 0; i < menuContentLarge.length; i++) {
        const content = menuContentLarge[i];
        const group = getParentMenuGroup(content);

        function handler() {
            const { right } = group.getBoundingClientRect();
            const { width } = content.getBoundingClientRect();

            const contentLeft = window.innerWidth - width - right;

            content.style.left = `${contentLeft < 0 ? contentLeft : 0}px`;
        }

        window.addEventListener('resize', handler);
        group.addEventListener('mouseenter', handler);
    }
}

//

/**
 * isScrollEnd check horizontal scroll end
 *
 * @param {Element} container
 * @returns bool
 */
function isScrollEnd(container, offset = 0) {
    return (
        container.offsetWidth + container.scrollLeft + offset >=
        container.scrollWidth
    );
}

/**
 * getScrollItemIndex get current index of the item in horizontal scroll list
 *
 * @param {Element} container
 * @returns {number}
 */
function getScrollItemIndex(container, offset = 10) {
    const children = container.children;

    if (children.length < 2) return 0;

    let offsetLeft = 0;

    for (let i = 0; i < children.length; i++) {
        const ele = children[i];

        const rect = ele.getBoundingClientRect();

        offsetLeft += rect.width;

        if (children[i + 1]) {
            offsetLeft +=
                children[i + 1].getBoundingClientRect().left - rect.right;
        }

        if (offsetLeft - offset > container.scrollLeft) return i;
    }
}

/**
 * scrollToNextItem scroll to next item
 *
 * @param {Element} container
 * @param {number} offset
 */
function scrollToNextItem(container, offset = 0) {
    const children = container.children;

    if (children.length < 2) return;

    let newOffsetLeft = 0;

    for (let i = 0; i < children.length; i++) {
        const ele = children[i];

        const rect = ele.getBoundingClientRect();

        newOffsetLeft += rect.width;

        if (children[i + 1]) {
            newOffsetLeft +=
                children[i + 1].getBoundingClientRect().left - rect.right;
        }

        if (newOffsetLeft > container.scrollLeft + offset) break;
    }

    container.scrollTo({
        left: newOffsetLeft,
        behavior: 'smooth',
    });
}

/**
 * scrollToPrivItem scroll to priv item
 *
 * @param {Element} container
 * @param {number} offset
 */
function scrollToPrivItem(container, offset = 0) {
    const children = container.children;

    let newOffsetLeft = 0;

    for (let i = 0; i < children.length; i++) {
        const ele = children[i];

        const rect = ele.getBoundingClientRect();

        let temp = newOffsetLeft + rect.width;

        if (children[i + 1]) {
            temp += children[i + 1].getBoundingClientRect().left - rect.right;
        }

        if (temp > container.scrollLeft + offset) break;
        newOffsetLeft = temp;
    }

    container.scrollTo({
        left: newOffsetLeft,
        behavior: 'smooth',
    });
}

/**
 * scrollToEleByIndex scroll to element by index
 *
 * @param {Element} container
 * @param {number} index
 * @param {'smooth' | 'instant' | 'auto'} [behavior='smooth']
 */
function scrollToEleByIndex(container, index, behavior = 'smooth') {
    const children = container.children;
    let newOffsetLeft = 0;
    let ind = index;
    if (index >= children.length) {
        ind = children.length;
    }

    for (let i = 0; i < ind; i++) {
        const ele = children[i];
        const rect = ele.getBoundingClientRect();

        newOffsetLeft += rect.width;
        if (children[i + 1]) {
            newOffsetLeft +=
                children[i + 1].getBoundingClientRect().left - rect.right;
        }
    }

    container.scrollTo({
        left: newOffsetLeft,
        behavior: behavior,
    });
}

/**
 * addHorizontalScrollEvent handle add event horizontal scroll
 *
 * @param {Element} container
 */
function addHorizontalScrollEvent(container) {
    let isScroll = false;
    let lastX = 0;
    let scrollDir = null;
    let lastScrollLeft = 0;
    let overflowLeft = 0;
    let overflowRight = 0;

    function handleScrollEnd() {
        if (overflowLeft) {
            overflowLeft = 0;
            container.children[0].style = `margin-left: ${0}px; transition: margin-left 0.2s ease-in-out;`;
        }
        if (overflowRight) {
            overflowRight = 0;
            container.children[
                container.children.length - 1
            ].style = `margin-right: ${0}px; transition: margin-right 0.2s ease-in-out;`;
        }

        lastX = 0;
        if (scrollDir > 0) scrollToNextItem(container, 0);
        if (scrollDir < 0) scrollToPrivItem(container, 0);

        scrollDir = 0;
        container.style = ``;

        setTimeout(() => {
            isScroll = false;
        });
    }

    function handleMove(e) {
        const isMouseDown = e.pressure !== 0;

        if (isMouseDown && lastX !== 0 && lastX !== e.x) {
            container.style = `user-select: none;cursor: -webkit-grab; cursor: grab;`;
            isScroll = true;
            if (
                overflowLeft > 0 ||
                (container.scrollLeft === 0 && lastX - e.x < 0)
            ) {
                overflowLeft -= (lastX - e.x) / 4;
                container.children[0].style = `margin-left: ${overflowLeft}px`;

                lastX = e.x;
                return;
            }

            if (
                overflowRight > 0 ||
                (lastX - e.x > 0 && isScrollEnd(container))
            ) {
                overflowRight += (lastX - e.x) / 4;
                container.children[
                    container.children.length - 1
                ].style = `margin-right: ${overflowRight}px;`;

                if (lastX - e.x < 0) {
                    scrollDir = lastX - e.x;
                    lastX = e.x;
                    return;
                }
            }

            lastScrollLeft = container.scrollLeft + lastX - e.x;

            container.scrollTo({
                left: container.scrollLeft + lastX - e.x,
            });
        }

        if (isMouseDown) {
            scrollDir = lastX - e.x;
            lastX = e.x;

            return;
        }

        handleScrollEnd();
    }

    container.addEventListener(
        'wheel',
        (e) => {
            if (e.deltaX != 0) {
                e.preventDefault();
            }
        },
        {
            passive: false,
        }
    );
    window.addEventListener('mouseup', handleScrollEnd);
    window.addEventListener('touchend', handleScrollEnd);
    container.addEventListener('pointermove', handleMove);

    // disable draggable for a tags
    const linkTags = container.getElementsByTagName('a');

    for (const e of linkTags) {
        e.setAttribute('draggable', false);
        e.addEventListener('click', (e) => {
            if (isScroll) e.preventDefault();
        });
    }

    // disable draggable for img tags
    const img = container.getElementsByTagName('img');
    for (const e of img) {
        e.setAttribute('draggable', false);
        e.addEventListener('click', (e) => {
            if (isScroll) e.preventDefault();
        });
    }
}

/**
 *
 * @param {Element} container
 * @param {Element} button
 */
function addNavigationButtonLeftClickEvent(container, button) {
    button.addEventListener('click', () => {
        scrollToPrivItem(container, -10);
    });
}

/**
 *
 * @param {Element} container
 * @param {Element} button
 */
function addNavigationButtonRightClickEvent(container, button) {
    button.addEventListener('click', () => {
        scrollToNextItem(container, 10);
    });
}

// search
function initSearchModal() {
    const modal = document.querySelector('.search-modal');

    let isMouseDownOnModal = false;
    modal.addEventListener('mousedown', (e) => {
        if (e.target === modal) {
            isMouseDownOnModal = true;
        }
    });
    modal.addEventListener('mouseup', (e) => {
        if (e.target === modal && isMouseDownOnModal) {
            closeSearchModal();
        }
    });

    const closeButton = document.querySelector('.search-modal > button');
    closeButton.addEventListener('click', () => {
        closeSearchModal();
    });

    const input = document.querySelector(
        '.search-modal__search-form__input input'
    );

    const clearButton = document.querySelector(
        '.search-modal__search-form__input button'
    );

    const searchForm = document.querySelector('.search-modal__search-form');
    searchForm.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();
        return false;
    });

    // handle search
    const searchResultsContainer = document.querySelector(
        '.search-modal__search-form__search-results'
    );

    const loadingElement = document.querySelector(
        '.search-modal__search-form__input span'
    );

    let query = '';

    function handleSearch(q) {
        if (q == '') {
            searchResultsContainer.innerHTML = '';
            loadingElement.removeAttribute('data-state');
            return;
        }

        loadingElement.setAttribute('data-state', 'active');

        searchProducts(query.trim()).then((products) => {
            if (q !== query) return;

            loadingElement.removeAttribute('data-state');
            setSearchResult(searchResultsContainer, products);
        });
    }

    const handleSearchDebounce = debounce(handleSearch, 400);

    clearButton.addEventListener('click', () => {
        input.value = '';
        query = '';
        handleSearchDebounce('');
    });

    input.addEventListener('keyup', (e) => {
        const q = e.target.value;

        if (query.trim() === q.trim()) return;
        query = q;
        handleSearchDebounce(q);
    });
}

/**
 * 
 * @param {{
        id: number;
        name: string;
        description: string;
        image: string;
        type: string;
        price: number;
    }} record 
 * @returns {HTMLElement}
 */
function createSearchCompleteElement(record) {
    const a = document.createElement('a');
    a.href = '#';
    a.className = 'search-complete-item';

    const imgDiv = document.createElement('div');
    imgDiv.className = 'search-complete-item__img';
    const img = document.createElement('img');
    img.src = `img/${record.image}`;
    imgDiv.appendChild(img);

    a.appendChild(imgDiv);

    const detailDiv = document.createElement('div');
    detailDiv.className = 'search-complete-item__detail';
    const h2 = document.createElement('h2');
    h2.textContent = record.name;
    detailDiv.appendChild(h2);
    const p = document.createElement('p');
    p.textContent = record.description;
    detailDiv.appendChild(p);
    const span = document.createElement('span');
    span.textContent = `$${record.price.toFixed(2)}`;
    detailDiv.appendChild(span);

    a.appendChild(detailDiv);

    return a;
}

function createViewAllEle() {
    const ele = document.createElement('div');
    ele.className = 'search-complete-item-view-all';
    ele.innerHTML = '<a href="#">View All Results</a>';
    return ele;
}

/**
 *
 * @param {HTMLDivElement} container
 * @param { {
        id: number;
        name: string;
        description: string;
        image: string;
        type: string;
        price: number;
    }[]} result
 *
 */
function setSearchResult(container, result) {
    container.innerHTML = '';

    if (result.length === 0) {
        container.innerHTML =
            '<div class="search-complete-item-not-found">No results found</div>';
        return;
    }

    for (let i = 0; i < result.length; i++) {
        container.appendChild(createSearchCompleteElement(result[i]));
    }
    container.appendChild(createViewAllEle());
}

function openSearchModal() {
    const modal = document.querySelector('.search-modal');

    modal.setAttribute('data-state', 'open');
    document.body.style.overflow = 'hidden';
}

function closeSearchModal() {
    const modal = document.querySelector('.search-modal');

    modal.setAttribute('data-state', 'close');
    document.body.style.overflow = 'auto';
}

function toggleSearchModal() {
    const modal = document.querySelector('.search-modal');

    const currentState = modal.getAttribute('data-state');

    if (currentState && currentState === 'close') {
        modal.setAttribute('data-state', 'open');
        document.body.style.overflow = 'hidden';
    } else {
        modal.setAttribute('data-state', 'close');
        document.body.style.overflow = 'auto';
    }
}

function initHeaderShadowEvents(headerClassName = '.header', offset = 2) {
    const header = document.querySelector(headerClassName);
    if (!header) return;

    document.addEventListener('scroll', (e) => {
        if (document.documentElement.scrollTop > offset) {
            header.style.boxShadow = 'rgba(0, 0, 0, 0.15) 0px 1px 6px 0px';
        } else {
            header.style.boxShadow = 'none';
        }
    });
}

/**
 * removeUserSelected remove user selected
 */
function removeUserSelected() {
    if (window.getSelection) {
        if (window.getSelection().empty) {
            // Chrome
            window.getSelection().empty();
        } else if (window.getSelection().removeAllRanges) {
            // Firefox
            window.getSelection().removeAllRanges();
        }
    } else if (document.selection) {
        // IE?
        document.selection.empty();
    }
}
