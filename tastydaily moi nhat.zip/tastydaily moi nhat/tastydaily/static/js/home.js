const NUMBER_OF_ITEMS_PER_PAGE = 4;
/**
 * initTabEvents add events for tab
 *
 * @param {Element} tab
 */
function initTabEvents(tab) {
    const scrollContainer = tab.getElementsByClassName('scrollable').item(0);

    const navigationButtonLeft = tab.querySelector('.navigation-button-left');

    const navigationButtonRight = tab.querySelector('.navigation-button-right');

    const footer = tab.getElementsByClassName('tabs-footer').item(0);

    if (navigationButtonLeft) {
        addNavigationButtonLeftClickEvent(
            scrollContainer,
            navigationButtonLeft
        );

        navigationButtonLeft.setAttribute('data-state', 'disable');
    }

    if (navigationButtonRight)
        addNavigationButtonRightClickEvent(
            scrollContainer,
            navigationButtonRight
        );

    if (scrollContainer) addHorizontalScrollEvent(scrollContainer);

    for (
        let i = 0;
        i < scrollContainer.children.length / NUMBER_OF_ITEMS_PER_PAGE;
        i++
    ) {
        footer.appendChild(document.createElement('span'));
    }

    for (let i = 0; i < footer.children.length; i++) {
        footer.children[i].addEventListener('click', () => {
            scrollToEleByIndex(scrollContainer, i * NUMBER_OF_ITEMS_PER_PAGE);
        });
    }

    footer.children[0].setAttribute('data-state', 'active');

    scrollContainer.addEventListener('scroll', () => {
        const currIndex = getScrollItemIndex(scrollContainer);

        const isLast = isScrollEnd(scrollContainer, 4);

        if (currIndex === 0) {
            navigationButtonLeft.setAttribute('data-state', 'disable');
        } else {
            navigationButtonLeft.removeAttribute('data-state');
        }

        if (isLast) {
            navigationButtonRight.setAttribute('data-state', 'disable');
        } else {
            navigationButtonRight.removeAttribute('data-state');
        }

        const activeIndex = isLast
            ? footer.children.length - 1
            : Number.parseInt(currIndex / NUMBER_OF_ITEMS_PER_PAGE);

        for (let i = 0; i < footer.children.length; i++) {
            if (activeIndex === i) {
                footer.children[i].setAttribute('data-state', 'active');
            } else {
                footer.children[i].removeAttribute('data-state');
            }
        }
    });
}

/**
 *
 * @param {HTMLDivElement} container
 */
function initBlogContainerEvents(container) {
    const scrollContainer = container.querySelector('.scrollable');

    const navigationButtonLeft = container.querySelector(
        '.navigation-button-left'
    );

    const navigationButtonRight = container.querySelector(
        '.navigation-button-right'
    );

    if (navigationButtonLeft) {
        addNavigationButtonLeftClickEvent(
            scrollContainer,
            navigationButtonLeft
        );

        navigationButtonLeft.setAttribute('data-state', 'disable');
    }

    if (!scrollContainer) return;

    if (navigationButtonRight)
        addNavigationButtonRightClickEvent(
            scrollContainer,
            navigationButtonRight
        );

    addHorizontalScrollEvent(scrollContainer);

    scrollContainer.addEventListener('scroll', () => {
        const currIndex = getScrollItemIndex(scrollContainer);

        const isLast = isScrollEnd(scrollContainer, 25);

        if (currIndex === 0) {
            navigationButtonLeft.setAttribute('data-state', 'disable');
        } else {
            navigationButtonLeft.removeAttribute('data-state');
        }

        if (isLast) {
            navigationButtonRight.setAttribute('data-state', 'disable');
        } else {
            navigationButtonRight.removeAttribute('data-state');
        }
    });
}

/**
 *
 * @param {HTMLDivElement} container
 */
function initFeaturedCategoriesContainerEvents(container) {
    const scrollContainer = container
        .getElementsByClassName('scrollable')
        .item(0);

    const navigationButtonLeft = container
        .getElementsByClassName('bt-left')
        .item(0);

    const navigationButtonRight = container
        .getElementsByClassName('bt-right')
        .item(0);

    if (navigationButtonLeft) {
        addNavigationButtonLeftClickEvent(
            scrollContainer,
            navigationButtonLeft
        );

        navigationButtonLeft.setAttribute('data-state', 'disable');
    }

    if (!scrollContainer) return;

    if (navigationButtonRight)
        addNavigationButtonRightClickEvent(
            scrollContainer,
            navigationButtonRight
        );

    addHorizontalScrollEvent(scrollContainer);

    scrollContainer.addEventListener('scroll', () => {
        const currIndex = getScrollItemIndex(scrollContainer);

        const isLast = isScrollEnd(scrollContainer, 4);

        if (currIndex === 0) {
            navigationButtonLeft.setAttribute('data-state', 'disable');
        } else {
            navigationButtonLeft.removeAttribute('data-state');
        }

        if (isLast) {
            navigationButtonRight.setAttribute('data-state', 'disable');
        } else {
            navigationButtonRight.removeAttribute('data-state');
        }
    });
}

/**
 *
 * @param {HTMLDivElement} container
 */
function initTestimonialsEvents(container) {
    const scrollContainer = container.querySelector('.scrollable');

    const navigationButtonLeft = container.querySelector(
        '.navigation-button-left'
    );

    const navigationButtonRight = container.querySelector(
        '.navigation-button-right'
    );

    if (navigationButtonLeft) {
        addNavigationButtonLeftClickEvent(
            scrollContainer,
            navigationButtonLeft
        );
    }

    if (!scrollContainer) return;

    if (navigationButtonRight)
        addNavigationButtonRightClickEvent(
            scrollContainer,
            navigationButtonRight
        );

    addHorizontalScrollEvent(scrollContainer);

    let lastIndex = getScrollItemIndex(scrollContainer);

    // infinity scroll
    scrollContainer.addEventListener('scroll', () => {
        const children = scrollContainer.children;
        const itemWidth = children[0].clientWidth;

        let currIndex = getScrollItemIndex(scrollContainer);

        if (lastIndex == currIndex) return;
        if (lastIndex == 0) {
            lastIndex = currIndex;
            return;
        }

        // scroll from right to left

        if (currIndex > lastIndex) {
            const [temp] = children;

            scrollContainer.append(temp);
            scrollToEleByIndex(scrollContainer, lastIndex, 'instant');

            lastIndex = currIndex - 1;

            return;
        }

        // scroll from left to right
        currIndex = getScrollItemIndex(scrollContainer, itemWidth - 10);
        if (currIndex == lastIndex) return;

        const firstChild = children[0];
        const lastChild = children[children.length];
        scrollContainer.insertBefore(firstChild, lastChild);

        scrollToEleByIndex(scrollContainer, lastIndex + 1, 'instant');
    });

    let isMouseOver = false;

    scrollContainer.addEventListener('mouseover', () => {
        isMouseOver = true;
    });

    scrollContainer.addEventListener('mouseleave', () => {
        isMouseOver = false;
    });

    setInterval(() => {
        if (isMouseOver) return;
        scrollToNextItem(scrollContainer, 10);
    }, 5000);
}

/**
 *
 * @param {HTMLDivElement} container
 * @param {number} time
 */
function initCountdownEvent(container, time) {
    const weeks = container.getElementsByClassName('weeks').item(0);
    const days = container.getElementsByClassName('days').item(0);
    const hours = container.getElementsByClassName('hours').item(0);
    const minutes = container.getElementsByClassName('minutes').item(0);
    const seconds = container.getElementsByClassName('seconds').item(0);

    let countdown = time;
    let lastTime = Date.now();

    // update time
    setInterval(() => {
        const currentTime = Date.now();
        countdown -= currentTime - lastTime;

        seconds.innerHTML = Math.round((countdown / 1000) % 60);
        minutes.innerHTML = Math.floor((countdown / 60000) % 60);
        hours.innerHTML = Math.floor((countdown / 3600000) % 24);
        days.innerHTML = Math.floor((countdown / 86400000) % 7);
        weeks.innerHTML = Math.floor(countdown / 604800000);

        lastTime = currentTime;
    }, 500);
}

/**
 * initSearchForm
 * @param {HTMLElement} searchForm
 */
function initSearchForm(searchForm) {
    const input = searchForm.querySelector('input');
    const loadingElement = searchForm.querySelector('span');
    const clearButton = searchForm.querySelector('button');
    const searchResultsContainer = searchForm.querySelector('.search-results');

    let query = '';
    function handleSearch(q) {
        if (q == '') {
            searchResultsContainer.innerHTML = '';
            loadingElement.removeAttribute('data-state');
            return;
        }

        loadingElement.setAttribute('data-state', 'active');

        searchProducts(query.trim()).then((products) => {
            if (q !== query) return;

            loadingElement.removeAttribute('data-state');
            setSearchResult(searchResultsContainer, products);
        });
    }
    const handleSearchDebounce = debounce(handleSearch, 400);

    clearButton.addEventListener('click', () => {
        input.value = '';
        query = '';
        handleSearchDebounce('');
    });
    input.addEventListener('keyup', (e) => {
        const q = e.target.value;

        if (query.trim() === q.trim()) return;
        query = q;
        handleSearchDebounce(q);
    });
}

// main func
(() => {
    initHeaderShadowEvents(undefined, 56);
    initCategoriesMenuButtonEvent();

    const blogContainer = document.querySelector('.blogs-container');

    initBlogContainerEvents(blogContainer);

    const a = document.querySelector('.featured-categories-container');
    initFeaturedCategoriesContainerEvents(a);

    const countdownContainer = document.querySelector('.countdown');
    initCountdownEvent(countdownContainer, 1000 * 60 * 60 * 24 * 10);

    const tapsContainer = document.querySelector('.products-tabs-container');

    const labels = tapsContainer.querySelectorAll(`.tabs-header label`);
    const tabContents = tapsContainer.querySelectorAll(`.tabs-content`);

    tabContents.forEach((tab) => {
        initTabEvents(tab);
    });

    labels.forEach((label) => {
        label.addEventListener('click', () => {
            labelFor = label.getAttribute('for');
            tabContents.forEach((tab) => {
                if (tab.getAttribute('data-name') === labelFor) {
                    tab.setAttribute('data-state', 'active');
                } else {
                    tab.removeAttribute('data-state');
                }
            });
        });
    });

    const testimonialList = document.querySelector('.testimonial-list');
    initTestimonialsEvents(testimonialList);

    //
    const openSearchButton = document.getElementById('open-search-button');
    openSearchButton.addEventListener('click', () => {
        openSearchModal();
    });

    const searchForm = document.querySelector('header .search-form');
    initSearchForm(searchForm);
    initSearchModal();
})();
